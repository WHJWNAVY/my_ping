static char SNAPSHOT[] = "s20121221";
